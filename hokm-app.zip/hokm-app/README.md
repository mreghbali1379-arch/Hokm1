# بازی حکم 🂡

اپ اندروید بازی حکم ۴ نفره (شما + یار در برابر دو حریف) با هوش مصنوعی.
کاملاً **آفلاین** است و بعد از نصب به اینترنت نیاز ندارد.

## ساختار

```
www/index.html         خود بازی (تک‌فایل، بدون وابستگی)
resources/             آیکون و اسپلش اپ
capacitor.config.json  نام و شناسه اپ
.github/workflows/     ساخت خودکار APK
```

## مراحل ساخت اپ با گیت‌هاب (بدون نصب چیزی روی کامپیوتر)

### ۱. ساخت مخزن
در github.com وارد حساب شوید، **New repository** بزنید، نام `hokm-app` را بدهید و مخزن را بدون README بسازید.

### ۲. آپلود فایل‌ها
**روش آسان (بدون git):** در صفحه مخزن روی **uploading an existing file** بزنید و *همه محتویات* پوشه پروژه را بکشید و رها کنید، سپس **Commit changes**.
> پوشه مخفی `.github` باید آپلود شود. اگر در سیستم شما دیده نمی‌شود، نمایش فایل‌های مخفی را روشن کنید.

**روش git:**
```bash
git init
git add .
git commit -m "نسخه اول"
git branch -M main
git remote add origin https://github.com/USERNAME/hokm-app.git
git push -u origin main
```

### ۳. ساخت APK
با هر push روی شاخه `main`، ساخت خودکار شروع می‌شود (حدود ۵ تا ۱۰ دقیقه).
برای شروع دستی: تب **Actions ← Build Android APK ← Run workflow**.

### ۴. دانلود APK
- وقتی کار سبز شد، روی آن کلیک کنید و از پایین صفحه، بخش **Artifacts** فایل `hokm-apk` را دانلود کنید (zip است؛ داخلش `hokm.apk` قرار دارد).
- **راه ساده‌تر برای دانلود از گوشی:** یک تگ نسخه بسازید تا APK در بخش Releases قرار بگیرد:
  ```bash
  git tag v1.0.0
  git push origin v1.0.0
  ```
  سپس در صفحه مخزن، بخش **Releases** فایل `hokm.apk` را مستقیم دارد.

### ۵. نصب روی گوشی
۱. فایل `hokm.apk` را به گوشی منتقل یا مستقیم دانلود کنید.
۲. روی آن بزنید. اگر گوشی پرسید، **نصب از این منبع** را برای مرورگر یا مدیر فایل مجاز کنید.
۳. نصب را تأیید کنید. اپ «بازی حکم» در لیست برنامه‌ها ظاهر می‌شود و بدون اینترنت کار می‌کند.

## ساخت روی کامپیوتر (اختیاری)

پیش‌نیاز: Node.js 20، JDK 21 و Android SDK.

```bash
npm install
npx cap add android
npm run assets
npm run sync
npm run android:apk
```
خروجی: `android/app/build/outputs/apk/debug/app-debug.apk`

## تغییر نام و شناسه

در `capacitor.config.json` مقادیر `appName` و `appId` (مثلاً `com.yourname.hokm`) را عوض کنید.

## نکات

- APK ساخته‌شده با کلید دیباگ امضا می‌شود؛ برای نصب شخصی مشکلی ندارد.
- برای انتشار در گوگل‌پلی باید نسخه release را با کلید امضای خودتان بسازید و کلید را هرگز در گیت‌هاب نگذارید.
- برای به‌روزرسانی بازی فقط `www/index.html` را تغییر دهید و دوباره push کنید.

## مجوز
MIT
